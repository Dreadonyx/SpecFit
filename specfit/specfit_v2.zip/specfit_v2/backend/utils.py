def bytes_to_gb(bytes_value):
    return round(bytes_value / (1000 ** 3), 2)