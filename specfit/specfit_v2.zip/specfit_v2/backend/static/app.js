const cpuEl = document.getElementById("cpu");
const memEl = document.getElementById("memory");
const verdictEl = document.getElementById("verdict");
const aiEl = document.getElementById("ai-insight");

const cpuBar = document.getElementById("cpu-bar");
const memBar = document.getElementById("memory-bar");

const usedEl = document.getElementById("mem-used");
const freeEl = document.getElementById("mem-free");
const availEl = document.getElementById("mem-avail");

function setVerdictColor(v) {
  if (v === "NORMAL") verdictEl.style.color = "#22c55e";
  else if (v === "STRAINED") verdictEl.style.color = "#f59e0b";
  else verdictEl.style.color = "#ef4444";
}

function loadStatus() {
  fetch("/status")
    .then(res => res.json())
    .then(data => {
      cpuEl.textContent = data.cpu_usage + "%";
      memEl.textContent = data.memory_usage + "%";

      cpuBar.style.width = data.cpu_usage + "%";
      memBar.style.width = data.memory_usage + "%";

      verdictEl.textContent = data.verdict;
      setVerdictColor(data.verdict);

      aiEl.textContent = data.ai_insight;

      usedEl.textContent = data.memory.used_gb;
      freeEl.textContent = data.memory.free_gb;
      availEl.textContent = data.memory.available_gb;

    })
    .catch(() => {
      verdictEl.textContent = "ERROR";
      aiEl.textContent = "Unable to fetch data";
    });
}

loadStatus();
document
  .getElementById("refresh-btn")
  .addEventListener("click", loadStatus);

