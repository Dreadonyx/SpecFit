import os
import requests
import psutil
from dotenv import load_dotenv
from flask import Flask, render_template, jsonify
from flask_cors import CORS

load_dotenv()

app = Flask(__name__)
CORS(app)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_ENDPOINT = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "gemini-1.5-flash:generateContent"
)

NORMAL_MESSAGE = "System stable. No action needed."

def get_verdict(cpu, memory):
    if memory < 70:
        return "NORMAL"
    if memory < 85:
        return "STRAINED"
    return "OVERLOADED"

def get_ai_insight(verdict, cpu, memory):
    if verdict == "NORMAL":
        return NORMAL_MESSAGE

    prompt = f"""
You are system monitor manager who monitors system performance.
You must give an AI insight by monitoring the cpu memory and verdict given to u and display a short review in structured way.
you must also give a fix which decreases memory usage
Total length must be under 30 characters.

CPU: {cpu}%
Memory: {memory}%
Verdict: {verdict}
"""

    response = requests.post(
        f"{GEMINI_ENDPOINT}?key={GEMINI_API_KEY}",
        json={
            "contents": [
                {"parts": [{"text": prompt}]}
            ]
        },
        timeout=6
    )

    text = (
        response.json()
        .get("candidates", [{}])[0]
        .get("content", {})
        .get("parts", [{}])[0]
        .get("text", "")
        .strip()
    )

    if not text:
        return "System under memory pressure"

    return text

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/status")
def status():
    cpu = psutil.cpu_percent(interval=1)

    mem = psutil.virtual_memory()

    memory_percent = mem.percent
    used_gb = round(mem.used / (1024 ** 3), 1)
    free_gb = round(mem.free / (1024 ** 3), 1)
    avail_gb = round(mem.available / (1024 ** 3), 1)

    verdict = get_verdict(cpu, memory_percent)
    ai_insight = get_ai_insight(verdict, cpu, memory_percent)

    return jsonify({
        "cpu_usage": round(cpu, 1),
        "memory_usage": round(memory_percent, 1),
        "memory": {
            "used_gb": used_gb,
            "free_gb": free_gb,
            "available_gb": avail_gb
        },
        "verdict": verdict,
        "ai_insight": ai_insight
    })

if __name__ == "__main__":
    app.run(debug=True)
